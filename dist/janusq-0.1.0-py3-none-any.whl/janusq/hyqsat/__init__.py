from .pyTest import solveByHyqsat, solveByMinisat
from .common.read_cnf import readCNF
from .common.reduce import reduce_to_3sat